#!/usr/bin/env python
import xlrd
import mysql.connector

path = ("C:/xampp/htdocs/OpenProject/ReporteActividades.xls")

wb = xlrd.open_workbook(path)
sheet = wb.sheet_by_index(0)
for row in range(sheet.nrows):
	date1 = sheet.cell_value(row,1)
	date2 = sheet.cell_value(row,4)
	if date1 == "" and date2 == "":
		break
	print(date1,date2)
	
	conexion = mysql.connector.connect(host='localhost', user='Esteban', passwd='123456', database='openproject')
	cursor = conexion.cursor()
	sql = "INSERT INTO sincronizar (id_tarea,tiempo) VALUES (%s,%s)"
	datos = (date1, date2)
	cursor.execute(sql,datos)
	conexion.commit()
	conexion.close()