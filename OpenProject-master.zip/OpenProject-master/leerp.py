#!/usr/bin/env python
import xlrd
import psycopg2
date1=""
date2=""
date3=""

path = ("C:/xampp/htdocs/OpenProject/ReporteActividades.xls")

wb = xlrd.open_workbook(path)
sheet = wb.sheet_by_index(0)
for row in range(sheet.nrows):
	if not (sheet.cell_value(row,3)=="DATE"):
		date1 = sheet.cell_value(row,3)
		date2 = sheet.cell_value(row,1)
		date3 = sheet.cell_value(row,4)
		if date1 == "" and date2 == "" and date3 == "":
			break
		print(date1,date2,date3)
	
		conexion = psycopg2.connect(database='sincronizar', user='postgres', password='root')
		cursor = conexion.cursor()
		sql = "INSERT INTO informacion(fecha,id_tarea,tiempo,estado) VALUES (%s,%s,%s,0)"
		datos = (date1, date2, date3)
		cursor.execute(sql,datos)
		conexion.commit()
		conexion.close()