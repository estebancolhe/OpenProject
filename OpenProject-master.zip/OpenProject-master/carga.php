<?php
$nombre_archivo = $_FILES['userfile']['name'];
$tipo_archivo = $_FILES['userfile']['type'];
$tamano_archivo = $_FILES['userfile']['size'];
	
if (!((strpos($tipo_archivo, "vnd.ms-excel") || strpos($tipo_archivo, "csv")) && ($tamano_archivo < 100000))) {
   	echo "La extensión o el tamaño de los archivos no es correcta. <br><br><table><tr><td><li>Se permiten archivos .gif o .jpg<br><li>se permiten archivos de 100 Kb máximo.</td></tr></table>";
   	echo $tamano_archivo."<br>";
   	 	echo $nombre_archivo."<br>";
   	echo strpos($tipo_archivo, "vnd.ms-excel");

}else{
   	if (move_uploaded_file($_FILES['userfile']['tmp_name'], "ReporteActividades.xls")){
      		echo "El archivo ha sido cargado correctamente.";
   	}else{
      		echo "Ocurrió algún error al subir el fichero. No pudo guardarse.";
   	}
}
$output = array();




//echo exec("python C:/xampp/htdocs/OpenProject/leerp.py",$output);
$command = escapeshellcmd('python leerp.py');
$output = shell_exec($command);
echo $output; 

?>